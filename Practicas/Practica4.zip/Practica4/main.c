#include "p4.h"

int main() {
    principal();
}