#include "practica1.h"

int main() {
  start();
  return 0;
}