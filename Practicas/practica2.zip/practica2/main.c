#include "p2.h"

int main(){
  inicio();
}